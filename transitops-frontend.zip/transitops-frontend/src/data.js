// In-memory mock data + business rules for TransitOps
// Replace these with real API calls once the backend is ready.

let idCounter = 1000;
export const nextId = () => `${idCounter++}`;

export const VEHICLE_STATUS = ['Available', 'On Trip', 'In Shop', 'Retired'];
export const DRIVER_STATUS = ['Available', 'On Trip', 'Off Duty', 'Suspended'];
export const TRIP_STATUS = ['Draft', 'Dispatched', 'Completed', 'Cancelled'];

export const initialVehicles = [
  { id: 'V-1001', regNo: 'TN-05-AB-1234', name: 'Van-05', type: 'Van', maxLoad: 500, odometer: 18240, cost: 1250000, status: 'Available' },
  { id: 'V-1002', regNo: 'TN-09-CD-4321', name: 'Truck-11', type: 'Truck', maxLoad: 2000, odometer: 54210, cost: 3200000, status: 'On Trip' },
  { id: 'V-1003', regNo: 'TN-02-EF-7788', name: 'Van-02', type: 'Van', maxLoad: 450, odometer: 9800, cost: 1180000, status: 'In Shop' },
  { id: 'V-1004', regNo: 'TN-11-GH-9012', name: 'Mini-Truck-03', type: 'Mini Truck', maxLoad: 900, odometer: 30250, cost: 1750000, status: 'Retired' },
];

export const initialDrivers = [
  { id: 'D-2001', name: 'Alex Rodriguez', license: 'DL-88213', category: 'LMV', expiry: '2027-03-14', contact: '9876543210', safetyScore: 92, status: 'Available' },
  { id: 'D-2002', name: 'Priya Sharma', license: 'DL-77410', category: 'HMV', expiry: '2026-08-02', contact: '9876501234', safetyScore: 88, status: 'On Trip' },
  { id: 'D-2003', name: 'Marcus Lee', license: 'DL-55921', category: 'LMV', expiry: '2025-01-10', contact: '9876511111', safetyScore: 74, status: 'Available' }, // expired license
  { id: 'D-2004', name: 'Jordan Kim', license: 'DL-31220', category: 'HMV', expiry: '2027-11-30', contact: '9876522222', safetyScore: 65, status: 'Suspended' },
];

export const initialTrips = [
  { id: 'T-3001', source: 'Chennai Depot', destination: 'Bengaluru Hub', vehicleId: 'V-1002', driverId: 'D-2002', cargoWeight: 1400, distance: 350, status: 'Dispatched', fuelConsumed: null, finalOdometer: null },
];

export const initialMaintenance = [
  { id: 'M-4001', vehicleId: 'V-1003', type: 'Oil Change', description: 'Routine 10k service', cost: 3500, date: '2026-07-10', status: 'Active' },
];

export const initialFuelLogs = [
  { id: 'F-5001', vehicleId: 'V-1002', liters: 80, cost: 9200, date: '2026-07-08' },
];

export const initialExpenses = [
  { id: 'E-6001', vehicleId: 'V-1002', type: 'Toll', amount: 640, date: '2026-07-08' },
];

// ---------- Business rule helpers ----------

export function isLicenseExpired(driver) {
  return new Date(driver.expiry) < new Date();
}

export function canDispatch({ vehicle, driver, cargoWeight }) {
  const errors = [];
  if (!vehicle) errors.push('Select a vehicle.');
  if (!driver) errors.push('Select a driver.');
  if (vehicle && vehicle.status !== 'Available') {
    errors.push(`Vehicle ${vehicle.regNo} is not Available (currently ${vehicle.status}).`);
  }
  if (driver && driver.status !== 'Available') {
    errors.push(`Driver ${driver.name} is not Available (currently ${driver.status}).`);
  }
  if (driver && isLicenseExpired(driver)) {
    errors.push(`Driver ${driver.name}'s license expired on ${driver.expiry}.`);
  }
  if (vehicle && cargoWeight > vehicle.maxLoad) {
    errors.push(`Cargo weight (${cargoWeight}kg) exceeds ${vehicle.regNo}'s max load (${vehicle.maxLoad}kg).`);
  }
  return errors;
}

export function fleetUtilization(vehicles) {
  const usable = vehicles.filter(v => v.status !== 'Retired');
  if (usable.length === 0) return 0;
  const onTrip = usable.filter(v => v.status === 'On Trip').length;
  return Math.round((onTrip / usable.length) * 100);
}

export function operationalCost(vehicleId, maintenance, fuelLogs, expenses) {
  const m = maintenance.filter(x => x.vehicleId === vehicleId).reduce((s, x) => s + Number(x.cost || 0), 0);
  const f = fuelLogs.filter(x => x.vehicleId === vehicleId).reduce((s, x) => s + Number(x.cost || 0), 0);
  const e = expenses.filter(x => x.vehicleId === vehicleId).reduce((s, x) => s + Number(x.amount || 0), 0);
  return { maintenance: m, fuel: f, expenses: e, total: m + f + e };
}

export function fuelEfficiency(vehicleId, trips, fuelLogs) {
  const distance = trips
    .filter(t => t.vehicleId === vehicleId && t.status === 'Completed')
    .reduce((s, t) => s + Number(t.distance || 0), 0);
  const fuel = fuelLogs.filter(f => f.vehicleId === vehicleId).reduce((s, f) => s + Number(f.liters || 0), 0);
  if (fuel === 0) return 0;
  return +(distance / fuel).toFixed(2);
}

export function vehicleROI(vehicle, revenue, maintenance, fuelLogs, expenses) {
  const { maintenance: m, fuel: f } = operationalCost(vehicle.id, maintenance, fuelLogs, expenses);
  if (!vehicle.cost) return 0;
  return +(((revenue - (m + f)) / vehicle.cost) * 100).toFixed(1);
}

export const CURRENT_USER = {
  name: 'Sam Whitfield',
  role: 'Fleet Manager', // one of: Fleet Manager, Driver, Safety Officer, Financial Analyst
};
