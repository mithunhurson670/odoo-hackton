import { useState } from 'react';
import Login from './components/Login.jsx';
import Sidebar from './components/Sidebar.jsx';
import Dashboard from './components/Dashboard.jsx';
import Vehicles from './components/Vehicles.jsx';
import Drivers from './components/Drivers.jsx';
import Trips from './components/Trips.jsx';
import Maintenance from './components/Maintenance.jsx';
import FuelExpense from './components/FuelExpense.jsx';
import Reports from './components/Reports.jsx';
import {
  initialVehicles, initialDrivers, initialTrips,
  initialMaintenance, initialFuelLogs, initialExpenses,
} from './data.js';

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('dashboard');

  const [vehicles, setVehicles] = useState(initialVehicles);
  const [drivers, setDrivers] = useState(initialDrivers);
  const [trips, setTrips] = useState(initialTrips);
  const [maintenance, setMaintenance] = useState(initialMaintenance);
  const [fuelLogs, setFuelLogs] = useState(initialFuelLogs);
  const [expenses, setExpenses] = useState(initialExpenses);

  if (!user) {
    return <Login onLogin={setUser} />;
  }

  return (
    <div className="app-shell">
      <Sidebar page={page} setPage={setPage} user={user} onLogout={() => setUser(null)} />
      <main className="main">
        <div className="topline" />
        {page === 'dashboard' && <Dashboard vehicles={vehicles} drivers={drivers} trips={trips} />}
        {page === 'vehicles' && <Vehicles vehicles={vehicles} setVehicles={setVehicles} />}
        {page === 'drivers' && <Drivers drivers={drivers} setDrivers={setDrivers} />}
        {page === 'trips' && (
          <Trips
            trips={trips} setTrips={setTrips}
            vehicles={vehicles} setVehicles={setVehicles}
            drivers={drivers} setDrivers={setDrivers}
          />
        )}
        {page === 'maintenance' && (
          <Maintenance
            maintenance={maintenance} setMaintenance={setMaintenance}
            vehicles={vehicles} setVehicles={setVehicles}
          />
        )}
        {page === 'fuel' && (
          <FuelExpense
            vehicles={vehicles}
            fuelLogs={fuelLogs} setFuelLogs={setFuelLogs}
            expenses={expenses} setExpenses={setExpenses}
            maintenance={maintenance}
          />
        )}
        {page === 'reports' && (
          <Reports
            vehicles={vehicles} trips={trips}
            maintenance={maintenance} fuelLogs={fuelLogs} expenses={expenses}
          />
        )}
      </main>
    </div>
  );
}
