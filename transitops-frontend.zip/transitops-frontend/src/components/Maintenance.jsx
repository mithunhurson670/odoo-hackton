import { useState } from 'react';
import Plate from './Plate.jsx';
import { nextId } from '../data.js';

const empty = { vehicleId: '', type: '', description: '', cost: '', date: '' };

export default function Maintenance({ maintenance, setMaintenance, vehicles, setVehicles }) {
  const [form, setForm] = useState(empty);
  const [error, setError] = useState('');

  function raiseRecord(e) {
    e.preventDefault();
    if (!form.vehicleId || !form.type || !form.date) {
      setError('Vehicle, type, and date are required.');
      return;
    }
    const vehicle = vehicles.find(v => v.id === form.vehicleId);
    if (vehicle.status === 'Retired') {
      setError(`${vehicle.regNo} is Retired and cannot be sent for maintenance.`);
      return;
    }
    setError('');
    setMaintenance([...maintenance, { id: nextId(), ...form, cost: +form.cost || 0, status: 'Active' }]);
    // Rule: creating an active maintenance record auto-switches vehicle to In Shop
    setVehicles(vehicles.map(v => v.id === form.vehicleId ? { ...v, status: 'In Shop' } : v));
    setForm(empty);
  }

  function closeRecord(record) {
    setMaintenance(maintenance.map(m => m.id === record.id ? { ...m, status: 'Closed' } : m));
    const vehicle = vehicles.find(v => v.id === record.vehicleId);
    // Rule: closing restores vehicle to Available, unless Retired
    if (vehicle.status !== 'Retired') {
      setVehicles(vehicles.map(v => v.id === record.vehicleId ? { ...v, status: 'Available' } : v));
    }
  }

  function vehicleLabel(id) {
    const v = vehicles.find(v => v.id === id);
    return v ? `${v.regNo} — ${v.name}` : '—';
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Fleet health</div>
          <h1 className="page-title">Maintenance</h1>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">Raise a maintenance record</div>
        <form onSubmit={raiseRecord}>
          <div className="form-grid">
            <div className="field">
              <label>Vehicle</label>
              <select value={form.vehicleId} onChange={e => setForm({ ...form, vehicleId: e.target.value })}>
                <option value="">Select vehicle…</option>
                {vehicles.filter(v => v.status !== 'Retired').map(v => (
                  <option key={v.id} value={v.id}>{v.regNo} — {v.name}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>Type</label>
              <input value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} placeholder="Oil change, brake service…" />
            </div>
            <div className="field">
              <label>Description</label>
              <input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="field">
              <label>Cost</label>
              <input type="number" value={form.cost} onChange={e => setForm({ ...form, cost: e.target.value })} />
            </div>
            <div className="field">
              <label>Date</label>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} />
            </div>
          </div>
          {error && <div className="error-text">{error}</div>}
          <button type="submit" className="btn btn-primary">Raise record — sends vehicle to In Shop</button>
        </form>
      </div>

      <div className="panel">
        <div className="panel-title">Maintenance log ({maintenance.length})</div>
        <table>
          <thead>
            <tr><th>Vehicle</th><th>Type</th><th>Cost</th><th>Date</th><th>Status</th><th></th></tr>
          </thead>
          <tbody>
            {maintenance.map(m => (
              <tr key={m.id}>
                <td>{vehicleLabel(m.vehicleId)}</td>
                <td>{m.type}</td>
                <td className="mono">₹{m.cost.toLocaleString()}</td>
                <td className="mono">{m.date}</td>
                <td><Plate status={m.status === 'Active' ? 'Pending' : 'Completed'} /></td>
                <td>
                  {m.status === 'Active'
                    ? <button className="btn btn-sm btn-primary" onClick={() => closeRecord(m)}>Close — restore vehicle</button>
                    : <span className="text-muted small">Closed</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
