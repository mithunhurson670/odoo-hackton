import { useState } from 'react';

const ROLES = ['Fleet Manager', 'Driver', 'Safety Officer', 'Financial Analyst'];

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Fleet Manager');
  const [error, setError] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    if (!email || !password) {
      setError('Enter both email and password.');
      return;
    }
    // Mock auth — wire this to your real auth endpoint.
    onLogin({ name: email.split('@')[0], email, role });
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="brand" style={{ padding: 0, marginBottom: 18 }}>
          <span className="brand-mark" />
          <span className="brand-name">TransitOps</span>
        </div>
        <div className="login-title">Sign in</div>
        <div className="login-sub">Fleet, dispatch, and maintenance — one console.</div>

        <form onSubmit={handleSubmit}>
          <div className="field" style={{ marginBottom: 14 }}>
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
            />
          </div>
          <div className="field" style={{ marginBottom: 14 }}>
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>
          <div className="field" style={{ marginBottom: 18 }}>
            <label>Role (RBAC — mock)</label>
            <select value={role} onChange={(e) => setRole(e.target.value)}>
              {ROLES.map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>

          {error && <div className="error-text">{error}</div>}

          <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: 6 }}>
            Sign in
          </button>
        </form>

        <div className="hint-box">
          Demo mode: any email/password signs you in as the selected role.
          Hook this up to your real auth API before shipping.
        </div>
      </div>
    </div>
  );
}
