import { useState } from 'react';
import Plate from './Plate.jsx';
import { DRIVER_STATUS, isLicenseExpired, nextId } from '../data.js';

const empty = { name: '', license: '', category: '', expiry: '', contact: '', safetyScore: '', status: 'Available' };

export default function Drivers({ drivers, setDrivers }) {
  const [form, setForm] = useState(empty);
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState(null);

  function resetForm() {
    setForm(empty);
    setEditingId(null);
    setError('');
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!form.name || !form.license || !form.expiry) {
      setError('Name, license number, and expiry date are required.');
      return;
    }
    const dup = drivers.find(d => d.license === form.license && d.id !== editingId);
    if (dup) {
      setError(`License number "${form.license}" is already registered to ${dup.name}.`);
      return;
    }
    const payload = { ...form, safetyScore: +form.safetyScore || 0 };
    if (editingId) {
      setDrivers(drivers.map(d => d.id === editingId ? { ...d, ...payload } : d));
    } else {
      setDrivers([...drivers, { id: nextId(), ...payload }]);
    }
    resetForm();
  }

  function editDriver(d) {
    setEditingId(d.id);
    setForm({ name: d.name, license: d.license, category: d.category, expiry: d.expiry, contact: d.contact, safetyScore: d.safetyScore, status: d.status });
    setError('');
  }

  function removeDriver(id) {
    if (confirm('Remove this driver?')) {
      setDrivers(drivers.filter(d => d.id !== id));
      if (editingId === id) resetForm();
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Master data</div>
          <h1 className="page-title">Driver Management</h1>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">{editingId ? 'Edit driver' : 'Register a new driver'}</div>
        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <div className="field">
              <label>Name</label>
              <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
            </div>
            <div className="field">
              <label>License number</label>
              <input value={form.license} onChange={e => setForm({ ...form, license: e.target.value })} />
            </div>
            <div className="field">
              <label>License category</label>
              <input value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} placeholder="LMV / HMV" />
            </div>
            <div className="field">
              <label>License expiry</label>
              <input type="date" value={form.expiry} onChange={e => setForm({ ...form, expiry: e.target.value })} />
            </div>
            <div className="field">
              <label>Contact number</label>
              <input value={form.contact} onChange={e => setForm({ ...form, contact: e.target.value })} />
            </div>
            <div className="field">
              <label>Safety score (0–100)</label>
              <input type="number" min="0" max="100" value={form.safetyScore} onChange={e => setForm({ ...form, safetyScore: e.target.value })} />
            </div>
            <div className="field">
              <label>Status</label>
              <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                {DRIVER_STATUS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          {error && <div className="error-text">{error}</div>}
          <div style={{ display: 'flex', gap: 10, marginTop: 6 }}>
            <button type="submit" className="btn btn-primary">{editingId ? 'Save changes' : 'Register driver'}</button>
            {editingId && <button type="button" className="btn" onClick={resetForm}>Cancel</button>}
          </div>
        </form>
      </div>

      <div className="panel">
        <div className="panel-title">All drivers ({drivers.length})</div>
        <table>
          <thead>
            <tr>
              <th>Name</th><th>License</th><th>Category</th><th>Expiry</th><th>Safety score</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {drivers.map(d => (
              <tr key={d.id}>
                <td>{d.name}</td>
                <td className="mono">{d.license}</td>
                <td>{d.category}</td>
                <td className="mono" style={{ color: isLicenseExpired(d) ? 'var(--danger)' : 'inherit' }}>
                  {d.expiry}{isLicenseExpired(d) ? ' (expired)' : ''}
                </td>
                <td className="mono">{d.safetyScore}</td>
                <td><Plate status={d.status} /></td>
                <td>
                  <button className="btn btn-sm" onClick={() => editDriver(d)}>Edit</button>{' '}
                  <button className="btn btn-sm btn-danger" onClick={() => removeDriver(d.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
