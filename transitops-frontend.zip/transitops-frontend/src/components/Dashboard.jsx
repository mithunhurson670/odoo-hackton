import { useMemo, useState } from 'react';
import Plate from './Plate.jsx';
import { fleetUtilization } from '../data.js';

export default function Dashboard({ vehicles, drivers, trips }) {
  const [typeFilter, setTypeFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');

  const types = useMemo(() => ['All', ...new Set(vehicles.map(v => v.type))], [vehicles]);

  const filteredVehicles = vehicles.filter(v =>
    (typeFilter === 'All' || v.type === typeFilter) &&
    (statusFilter === 'All' || v.status === statusFilter)
  );

  const kpis = {
    active: filteredVehicles.filter(v => v.status !== 'Retired').length,
    available: filteredVehicles.filter(v => v.status === 'Available').length,
    inShop: filteredVehicles.filter(v => v.status === 'In Shop').length,
    activeTrips: trips.filter(t => t.status === 'Dispatched').length,
    pendingTrips: trips.filter(t => t.status === 'Draft').length,
    driversOnDuty: drivers.filter(d => d.status === 'On Trip' || d.status === 'Available').length,
    utilization: fleetUtilization(filteredVehicles),
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Operational snapshot</div>
          <h1 className="page-title">Dashboard</h1>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <div className="field" style={{ minWidth: 140 }}>
            <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
              {types.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="field" style={{ minWidth: 140 }}>
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
              {['All', 'Available', 'On Trip', 'In Shop', 'Retired'].map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-label">Active vehicles</div>
          <div className="kpi-value">{kpis.active}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Available vehicles</div>
          <div className="kpi-value go">{kpis.available}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">In maintenance</div>
          <div className="kpi-value accent">{kpis.inShop}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Active trips</div>
          <div className="kpi-value accent">{kpis.activeTrips}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Pending trips</div>
          <div className="kpi-value">{kpis.pendingTrips}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Drivers on duty</div>
          <div className="kpi-value go">{kpis.driversOnDuty}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Fleet utilization</div>
          <div className="kpi-value accent">{kpis.utilization}%</div>
        </div>
      </div>

      <div className="grid-2">
        <div className="panel">
          <div className="panel-title">Vehicles at a glance</div>
          <table>
            <thead>
              <tr><th>Reg No.</th><th>Name</th><th>Type</th><th>Status</th></tr>
            </thead>
            <tbody>
              {filteredVehicles.slice(0, 6).map(v => (
                <tr key={v.id}>
                  <td className="mono">{v.regNo}</td>
                  <td>{v.name}</td>
                  <td>{v.type}</td>
                  <td><Plate status={v.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="panel">
          <div className="panel-title">Active trips</div>
          <table>
            <thead>
              <tr><th>Trip</th><th>Route</th><th>Status</th></tr>
            </thead>
            <tbody>
              {trips.filter(t => t.status === 'Dispatched' || t.status === 'Draft').map(t => (
                <tr key={t.id}>
                  <td className="mono">{t.id}</td>
                  <td>{t.source} → {t.destination}</td>
                  <td><Plate status={t.status} /></td>
                </tr>
              ))}
              {trips.filter(t => t.status === 'Dispatched' || t.status === 'Draft').length === 0 && (
                <tr><td colSpan={3} className="text-muted">No active trips right now.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
