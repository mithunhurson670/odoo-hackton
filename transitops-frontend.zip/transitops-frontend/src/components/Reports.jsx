import { fleetUtilization, operationalCost, fuelEfficiency, vehicleROI } from '../data.js';

export default function Reports({ vehicles, trips, maintenance, fuelLogs, expenses }) {
  const rows = vehicles.map(v => {
    const cost = operationalCost(v.id, maintenance, fuelLogs, expenses);
    const efficiency = fuelEfficiency(v.id, trips, fuelLogs);
    // Revenue isn't in the spec's data model — treated as a placeholder input per vehicle for the ROI formula.
    const assumedRevenue = cost.total * 1.4;
    const roi = vehicleROI(v, assumedRevenue, maintenance, fuelLogs, expenses);
    return { ...v, ...cost, efficiency, roi, assumedRevenue };
  });

  function exportCSV() {
    const header = ['Reg No', 'Name', 'Fuel Efficiency (km/L)', 'Operational Cost', 'ROI (%)'];
    const lines = rows.map(r => [r.regNo, r.name, r.efficiency, r.total, r.roi].join(','));
    const csv = [header.join(','), ...lines].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transitops_report.csv';
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Analytics</div>
          <h1 className="page-title">Reports</h1>
        </div>
        <button className="btn btn-primary" onClick={exportCSV}>Export CSV</button>
      </div>

      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-label">Fleet utilization</div>
          <div className="kpi-value accent">{fleetUtilization(vehicles)}%</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Total operational cost</div>
          <div className="kpi-value">₹{rows.reduce((s, r) => s + r.total, 0).toLocaleString()}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Avg fuel efficiency</div>
          <div className="kpi-value go">
            {(rows.reduce((s, r) => s + r.efficiency, 0) / (rows.length || 1)).toFixed(2)} km/L
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">Per-vehicle performance</div>
        <table>
          <thead>
            <tr>
              <th>Vehicle</th><th>Fuel efficiency</th><th>Operational cost</th><th>Assumed revenue*</th><th>ROI</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id}>
                <td>{r.regNo} — {r.name}</td>
                <td className="mono">{r.efficiency} km/L</td>
                <td className="mono">₹{r.total.toLocaleString()}</td>
                <td className="mono text-muted">₹{Math.round(r.assumedRevenue).toLocaleString()}</td>
                <td className="mono" style={{ color: r.roi >= 0 ? 'var(--go)' : 'var(--danger)' }}>{r.roi}%</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="small text-muted" style={{ marginTop: 10 }}>
          * Revenue per vehicle isn't part of the spec's data model — swap this placeholder for a real
          revenue field/source once the backend defines one. ROI = (Revenue − (Maintenance + Fuel)) / Acquisition Cost.
        </div>
      </div>
    </div>
  );
}
