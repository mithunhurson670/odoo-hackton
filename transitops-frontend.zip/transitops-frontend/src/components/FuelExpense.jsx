import { useState } from 'react';
import { nextId, operationalCost } from '../data.js';

const emptyFuel = { vehicleId: '', liters: '', cost: '', date: '' };
const emptyExpense = { vehicleId: '', type: '', amount: '', date: '' };

export default function FuelExpense({ vehicles, fuelLogs, setFuelLogs, expenses, setExpenses, maintenance }) {
  const [fuelForm, setFuelForm] = useState(emptyFuel);
  const [expForm, setExpForm] = useState(emptyExpense);

  function addFuel(e) {
    e.preventDefault();
    if (!fuelForm.vehicleId || !fuelForm.liters || !fuelForm.cost || !fuelForm.date) return;
    setFuelLogs([...fuelLogs, { id: nextId(), ...fuelForm, liters: +fuelForm.liters, cost: +fuelForm.cost }]);
    setFuelForm(emptyFuel);
  }

  function addExpense(e) {
    e.preventDefault();
    if (!expForm.vehicleId || !expForm.type || !expForm.amount || !expForm.date) return;
    setExpenses([...expenses, { id: nextId(), ...expForm, amount: +expForm.amount }]);
    setExpForm(emptyExpense);
  }

  function vehicleLabel(id) {
    const v = vehicles.find(v => v.id === id);
    return v ? `${v.regNo} — ${v.name}` : '—';
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Cost tracking</div>
          <h1 className="page-title">Fuel & Expenses</h1>
        </div>
      </div>

      <div className="grid-2">
        <div className="panel">
          <div className="panel-title">Log fuel</div>
          <form onSubmit={addFuel}>
            <div className="field" style={{ marginBottom: 12 }}>
              <label>Vehicle</label>
              <select value={fuelForm.vehicleId} onChange={e => setFuelForm({ ...fuelForm, vehicleId: e.target.value })}>
                <option value="">Select vehicle…</option>
                {vehicles.map(v => <option key={v.id} value={v.id}>{v.regNo} — {v.name}</option>)}
              </select>
            </div>
            <div className="form-grid">
              <div className="field">
                <label>Liters</label>
                <input type="number" value={fuelForm.liters} onChange={e => setFuelForm({ ...fuelForm, liters: e.target.value })} />
              </div>
              <div className="field">
                <label>Cost</label>
                <input type="number" value={fuelForm.cost} onChange={e => setFuelForm({ ...fuelForm, cost: e.target.value })} />
              </div>
              <div className="field">
                <label>Date</label>
                <input type="date" value={fuelForm.date} onChange={e => setFuelForm({ ...fuelForm, date: e.target.value })} />
              </div>
            </div>
            <button type="submit" className="btn btn-primary">Add fuel log</button>
          </form>
        </div>

        <div className="panel">
          <div className="panel-title">Log expense</div>
          <form onSubmit={addExpense}>
            <div className="field" style={{ marginBottom: 12 }}>
              <label>Vehicle</label>
              <select value={expForm.vehicleId} onChange={e => setExpForm({ ...expForm, vehicleId: e.target.value })}>
                <option value="">Select vehicle…</option>
                {vehicles.map(v => <option key={v.id} value={v.id}>{v.regNo} — {v.name}</option>)}
              </select>
            </div>
            <div className="form-grid">
              <div className="field">
                <label>Type</label>
                <input value={expForm.type} onChange={e => setExpForm({ ...expForm, type: e.target.value })} placeholder="Toll, parking…" />
              </div>
              <div className="field">
                <label>Amount</label>
                <input type="number" value={expForm.amount} onChange={e => setExpForm({ ...expForm, amount: e.target.value })} />
              </div>
              <div className="field">
                <label>Date</label>
                <input type="date" value={expForm.date} onChange={e => setExpForm({ ...expForm, date: e.target.value })} />
              </div>
            </div>
            <button type="submit" className="btn btn-primary">Add expense</button>
          </form>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">Operational cost by vehicle</div>
        <table>
          <thead>
            <tr><th>Vehicle</th><th>Fuel cost</th><th>Maintenance cost</th><th>Other expenses</th><th>Total</th></tr>
          </thead>
          <tbody>
            {vehicles.map(v => {
              const c = operationalCost(v.id, maintenance, fuelLogs, expenses);
              return (
                <tr key={v.id}>
                  <td>{v.regNo} — {v.name}</td>
                  <td className="mono">₹{c.fuel.toLocaleString()}</td>
                  <td className="mono">₹{c.maintenance.toLocaleString()}</td>
                  <td className="mono">₹{c.expenses.toLocaleString()}</td>
                  <td className="mono" style={{ color: 'var(--accent)' }}>₹{c.total.toLocaleString()}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
