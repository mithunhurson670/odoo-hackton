import { useState } from 'react';
import Plate from './Plate.jsx';
import { canDispatch, nextId } from '../data.js';

const emptyTrip = { source: '', destination: '', vehicleId: '', driverId: '', cargoWeight: '', distance: '' };

export default function Trips({ trips, setTrips, vehicles, setVehicles, drivers, setDrivers }) {
  const [form, setForm] = useState(emptyTrip);
  const [errors, setErrors] = useState([]);
  const [completingId, setCompletingId] = useState(null);
  const [completeForm, setCompleteForm] = useState({ finalOdometer: '', fuelConsumed: '' });

  const availableVehicles = vehicles.filter(v => v.status === 'Available');
  const availableDrivers = drivers.filter(d => d.status === 'Available');

  function createDraft(e) {
    e.preventDefault();
    if (!form.source || !form.destination || !form.vehicleId || !form.driverId || !form.cargoWeight) {
      setErrors(['All fields are required to create a trip.']);
      return;
    }
    setTrips([...trips, {
      id: nextId(),
      ...form,
      cargoWeight: +form.cargoWeight,
      distance: +form.distance,
      status: 'Draft',
      fuelConsumed: null,
      finalOdometer: null,
    }]);
    setForm(emptyTrip);
    setErrors([]);
  }

  function dispatchTrip(trip) {
    const vehicle = vehicles.find(v => v.id === trip.vehicleId);
    const driver = drivers.find(d => d.id === trip.driverId);
    const problems = canDispatch({ vehicle, driver, cargoWeight: trip.cargoWeight });
    if (problems.length) {
      setErrors(problems);
      return;
    }
    setErrors([]);
    setTrips(trips.map(t => t.id === trip.id ? { ...t, status: 'Dispatched' } : t));
    setVehicles(vehicles.map(v => v.id === vehicle.id ? { ...v, status: 'On Trip' } : v));
    setDrivers(drivers.map(d => d.id === driver.id ? { ...d, status: 'On Trip' } : d));
  }

  function cancelTrip(trip) {
    setTrips(trips.map(t => t.id === trip.id ? { ...t, status: 'Cancelled' } : t));
    if (trip.status === 'Dispatched') {
      setVehicles(vehicles.map(v => v.id === trip.vehicleId ? { ...v, status: 'Available' } : v));
      setDrivers(drivers.map(d => d.id === trip.driverId ? { ...d, status: 'Available' } : d));
    }
  }

  function openComplete(trip) {
    setCompletingId(trip.id);
    setCompleteForm({ finalOdometer: '', fuelConsumed: '' });
  }

  function submitComplete(trip) {
    if (!completeForm.finalOdometer || !completeForm.fuelConsumed) {
      setErrors(['Enter final odometer and fuel consumed to complete the trip.']);
      return;
    }
    setErrors([]);
    setTrips(trips.map(t => t.id === trip.id ? { ...t, status: 'Completed', finalOdometer: +completeForm.finalOdometer, fuelConsumed: +completeForm.fuelConsumed } : t));
    setVehicles(vehicles.map(v => v.id === trip.vehicleId ? { ...v, status: 'Available', odometer: +completeForm.finalOdometer } : v));
    setDrivers(drivers.map(d => d.id === trip.driverId ? { ...d, status: 'Available' } : d));
    setCompletingId(null);
  }

  function vehicleLabel(id) {
    const v = vehicles.find(v => v.id === id);
    return v ? `${v.regNo} — ${v.name}` : '—';
  }
  function driverLabel(id) {
    const d = drivers.find(d => d.id === id);
    return d ? d.name : '—';
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Dispatch</div>
          <h1 className="page-title">Trip Management</h1>
        </div>
      </div>

      {errors.length > 0 && (
        <div className="banner danger">
          {errors.map((e, i) => <div key={i}>• {e}</div>)}
        </div>
      )}

      <div className="panel">
        <div className="panel-title">Create trip (Draft)</div>
        <form onSubmit={createDraft}>
          <div className="form-grid">
            <div className="field">
              <label>Source</label>
              <input value={form.source} onChange={e => setForm({ ...form, source: e.target.value })} />
            </div>
            <div className="field">
              <label>Destination</label>
              <input value={form.destination} onChange={e => setForm({ ...form, destination: e.target.value })} />
            </div>
            <div className="field">
              <label>Vehicle (available only)</label>
              <select value={form.vehicleId} onChange={e => setForm({ ...form, vehicleId: e.target.value })}>
                <option value="">Select vehicle…</option>
                {availableVehicles.map(v => (
                  <option key={v.id} value={v.id}>{v.regNo} — {v.name} (max {v.maxLoad}kg)</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>Driver (available only)</label>
              <select value={form.driverId} onChange={e => setForm({ ...form, driverId: e.target.value })}>
                <option value="">Select driver…</option>
                {availableDrivers.map(d => (
                  <option key={d.id} value={d.id}>{d.name} — {d.license}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>Cargo weight (kg)</label>
              <input type="number" value={form.cargoWeight} onChange={e => setForm({ ...form, cargoWeight: e.target.value })} />
            </div>
            <div className="field">
              <label>Planned distance (km)</label>
              <input type="number" value={form.distance} onChange={e => setForm({ ...form, distance: e.target.value })} />
            </div>
          </div>
          <button type="submit" className="btn btn-primary">Create draft trip</button>
        </form>
      </div>

      <div className="panel">
        <div className="panel-title">All trips ({trips.length})</div>
        <table>
          <thead>
            <tr>
              <th>Trip</th><th>Route</th><th>Vehicle</th><th>Driver</th><th>Cargo</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {trips.map(t => (
              <tr key={t.id}>
                <td className="mono">{t.id}</td>
                <td>{t.source} → {t.destination}</td>
                <td>{vehicleLabel(t.vehicleId)}</td>
                <td>{driverLabel(t.driverId)}</td>
                <td className="mono">{t.cargoWeight} kg</td>
                <td><Plate status={t.status} /></td>
                <td style={{ minWidth: 210 }}>
                  {t.status === 'Draft' && (
                    <>
                      <button className="btn btn-sm btn-primary" onClick={() => dispatchTrip(t)}>Dispatch</button>{' '}
                      <button className="btn btn-sm btn-danger" onClick={() => cancelTrip(t)}>Cancel</button>
                    </>
                  )}
                  {t.status === 'Dispatched' && completingId !== t.id && (
                    <>
                      <button className="btn btn-sm btn-primary" onClick={() => openComplete(t)}>Complete</button>{' '}
                      <button className="btn btn-sm btn-danger" onClick={() => cancelTrip(t)}>Cancel</button>
                    </>
                  )}
                  {completingId === t.id && (
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <input
                        type="number" placeholder="Final odo"
                        style={{ width: 90, background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text)', padding: '5px 8px', borderRadius: 5 }}
                        value={completeForm.finalOdometer}
                        onChange={e => setCompleteForm({ ...completeForm, finalOdometer: e.target.value })}
                      />
                      <input
                        type="number" placeholder="Fuel (L)"
                        style={{ width: 80, background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text)', padding: '5px 8px', borderRadius: 5 }}
                        value={completeForm.fuelConsumed}
                        onChange={e => setCompleteForm({ ...completeForm, fuelConsumed: e.target.value })}
                      />
                      <button className="btn btn-sm btn-primary" onClick={() => submitComplete(t)}>Save</button>
                    </div>
                  )}
                  {(t.status === 'Completed' || t.status === 'Cancelled') && (
                    <span className="text-muted small">No actions</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
