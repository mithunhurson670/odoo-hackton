export default function Plate({ status }) {
  const slug = status.toLowerCase().replace(/\s+/g, '-');
  return <span className={`plate ${slug}`}>{status}</span>;
}
