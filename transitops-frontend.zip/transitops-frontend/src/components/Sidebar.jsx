const NAV = [
  { key: 'dashboard', label: 'Dashboard', icon: '◧' },
  { key: 'vehicles', label: 'Vehicle Registry', icon: '🚚' },
  { key: 'drivers', label: 'Drivers', icon: '🪪' },
  { key: 'trips', label: 'Trips', icon: '⇢' },
  { key: 'maintenance', label: 'Maintenance', icon: '🔧' },
  { key: 'fuel', label: 'Fuel & Expenses', icon: '⛽' },
  { key: 'reports', label: 'Reports', icon: '📊' },
];

export default function Sidebar({ page, setPage, user, onLogout }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <span className="brand-mark" />
        <span className="brand-name">TransitOps</span>
      </div>

      <ul className="nav-list">
        {NAV.map((item) => (
          <li
            key={item.key}
            className={`nav-item ${page === item.key ? 'active' : ''}`}
            onClick={() => setPage(item.key)}
          >
            <span className="nav-icon">{item.icon}</span>
            {item.label}
          </li>
        ))}
      </ul>

      <div className="sidebar-footer">
        <div>{user.name || user.email}</div>
        <span className="role-pill">{user.role}</span>
        <div style={{ marginTop: 10 }}>
          <button className="btn btn-sm" style={{ width: '100%' }} onClick={onLogout}>
            Sign out
          </button>
        </div>
      </div>
    </aside>
  );
}
