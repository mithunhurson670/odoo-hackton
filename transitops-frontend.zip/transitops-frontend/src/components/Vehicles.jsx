import { useState } from 'react';
import Plate from './Plate.jsx';
import { VEHICLE_STATUS, nextId } from '../data.js';

const empty = { regNo: '', name: '', type: '', maxLoad: '', odometer: '', cost: '', status: 'Available' };

export default function Vehicles({ vehicles, setVehicles }) {
  const [form, setForm] = useState(empty);
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState('');

  function resetForm() {
    setForm(empty);
    setEditingId(null);
    setError('');
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!form.regNo || !form.name || !form.type || !form.maxLoad) {
      setError('Registration number, name, type, and max load are required.');
      return;
    }
    const dup = vehicles.find(
      v => v.regNo.toLowerCase() === form.regNo.toLowerCase() && v.id !== editingId
    );
    if (dup) {
      setError(`Registration number "${form.regNo}" is already in use by ${dup.name}.`);
      return;
    }

    if (editingId) {
      setVehicles(vehicles.map(v => v.id === editingId ? { ...v, ...form, maxLoad: +form.maxLoad, odometer: +form.odometer, cost: +form.cost } : v));
    } else {
      setVehicles([...vehicles, { id: nextId(), ...form, maxLoad: +form.maxLoad, odometer: +form.odometer, cost: +form.cost }]);
    }
    resetForm();
  }

  function editVehicle(v) {
    setEditingId(v.id);
    setForm({ regNo: v.regNo, name: v.name, type: v.type, maxLoad: v.maxLoad, odometer: v.odometer, cost: v.cost, status: v.status });
    setError('');
  }

  function removeVehicle(id) {
    if (confirm('Remove this vehicle? This cannot be undone.')) {
      setVehicles(vehicles.filter(v => v.id !== id));
      if (editingId === id) resetForm();
    }
  }

  const filtered = vehicles.filter(v =>
    v.regNo.toLowerCase().includes(search.toLowerCase()) ||
    v.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-eyebrow">Master data</div>
          <h1 className="page-title">Vehicle Registry</h1>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">{editingId ? 'Edit vehicle' : 'Register a new vehicle'}</div>
        <form onSubmit={handleSubmit}>
          <div className="form-grid">
            <div className="field">
              <label>Registration number</label>
              <input value={form.regNo} onChange={e => setForm({ ...form, regNo: e.target.value })} placeholder="TN-05-AB-1234" />
            </div>
            <div className="field">
              <label>Name / model</label>
              <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Van-05" />
            </div>
            <div className="field">
              <label>Type</label>
              <input value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} placeholder="Van / Truck / Mini Truck" />
            </div>
            <div className="field">
              <label>Max load capacity (kg)</label>
              <input type="number" value={form.maxLoad} onChange={e => setForm({ ...form, maxLoad: e.target.value })} />
            </div>
            <div className="field">
              <label>Odometer (km)</label>
              <input type="number" value={form.odometer} onChange={e => setForm({ ...form, odometer: e.target.value })} />
            </div>
            <div className="field">
              <label>Acquisition cost</label>
              <input type="number" value={form.cost} onChange={e => setForm({ ...form, cost: e.target.value })} />
            </div>
            <div className="field">
              <label>Status</label>
              <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                {VEHICLE_STATUS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          {error && <div className="error-text">{error}</div>}
          <div style={{ display: 'flex', gap: 10, marginTop: 6 }}>
            <button type="submit" className="btn btn-primary">{editingId ? 'Save changes' : 'Register vehicle'}</button>
            {editingId && <button type="button" className="btn" onClick={resetForm}>Cancel</button>}
          </div>
        </form>
      </div>

      <div className="panel">
        <div className="panel-title">
          <span>All vehicles ({filtered.length})</span>
          <input
            placeholder="Search by reg no or name…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text)', padding: '6px 10px', borderRadius: 6, fontSize: 13 }}
          />
        </div>
        <table>
          <thead>
            <tr>
              <th>Reg No.</th><th>Name</th><th>Type</th><th>Max Load</th><th>Odometer</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(v => (
              <tr key={v.id}>
                <td className="mono">{v.regNo}</td>
                <td>{v.name}</td>
                <td>{v.type}</td>
                <td className="mono">{v.maxLoad} kg</td>
                <td className="mono">{v.odometer.toLocaleString()} km</td>
                <td><Plate status={v.status} /></td>
                <td>
                  <button className="btn btn-sm" onClick={() => editVehicle(v)}>Edit</button>{' '}
                  <button className="btn btn-sm btn-danger" onClick={() => removeVehicle(v.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
