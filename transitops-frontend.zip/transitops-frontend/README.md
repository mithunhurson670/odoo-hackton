# TransitOps — Frontend

React + Vite frontend for the TransitOps fleet operations platform. Runs entirely
on in-memory mock data right now — no backend required to demo it.

## Setup

```bash
npm install
npm run dev
```

Open the printed local URL (usually `http://localhost:5173`).

## Sign in

This is mock auth: any email + password logs you in. Pick a role from the
dropdown (Fleet Manager, Driver, Safety Officer, Financial Analyst) — it's
displayed in the sidebar but doesn't yet restrict pages. Wire real RBAC into
`src/components/Login.jsx` and gate routes in `src/App.jsx` once the backend
auth endpoint exists.

## Structure

```
src/
  data.js                 # mock data + all business-rule helpers (dispatch validation,
                           # fleet utilization, operational cost, fuel efficiency, ROI)
  App.jsx                 # top-level state + page routing
  components/
    Login.jsx
    Sidebar.jsx
    Plate.jsx              # shared status-badge component
    Dashboard.jsx
    Vehicles.jsx            # Vehicle Registry CRUD
    Drivers.jsx              # Driver Management CRUD
    Trips.jsx                # Trip lifecycle + dispatch validations
    Maintenance.jsx          # Maintenance workflow (auto vehicle status flips)
    FuelExpense.jsx
    Reports.jsx              # KPIs + CSV export
```

## Business rules already implemented (client-side, in `data.js` + components)

- Registration number uniqueness check on vehicle create/edit
- License number uniqueness check on driver create/edit
- Retired / In Shop vehicles excluded from trip dispatch dropdowns
- Suspended drivers / expired licenses excluded from trip dispatch dropdowns
- Cargo weight vs. vehicle max load validation
- Dispatch → vehicle & driver flip to "On Trip"
- Complete trip → vehicle & driver flip back to "Available", odometer updates
- Cancel dispatched trip → vehicle & driver restored to "Available"
- Raising a maintenance record → vehicle flips to "In Shop"
- Closing maintenance → vehicle restored to "Available" (unless Retired)
- Fleet utilization %, operational cost rollup, fuel efficiency, and ROI formulas

## Next steps to connect a real backend

1. Replace the `initial*` arrays in `data.js` with API calls (e.g. `fetch` on mount).
2. Replace local `setState` calls in each component with API mutation calls,
   then refetch or optimistically update.
3. Move `canDispatch`, `operationalCost`, etc. server-side too if you want
   validation enforced outside the client (recommended before real deployment).
4. Wire `Login.jsx` to a real auth endpoint and store a token/session.

## Design notes

Visual identity: dark control-room palette with an amber "route-line" accent,
Barlow Condensed for headers, JetBrains Mono for data (plates, odometer,
costs). The recurring "plate" component (license-plate-style status chip) is
the signature element tying the UI back to the vehicle domain — reuse it for
any new status field rather than inventing a new badge style.
