# TransitOps API

A REST backend for the `urban-logistics-ui` fleet-management app. Built with **Express** + **SQLite** (`better-sqlite3`), it mirrors the data model already used in the UI's `src/lib/mock.ts` so you can swap the mock fetchers for real HTTP calls with minimal changes.

## Stack

- Express (HTTP server + routing)
- better-sqlite3 (embedded, file-based SQL database — zero setup, no external DB server needed)
- JWT auth (`jsonwebtoken` + `bcryptjs`)
- Zod (request validation)

## Setup

```bash
cd backend
npm install
npm run seed   # creates data/transitops.db and loads demo data + demo user
npm start       # http://localhost:4000
```

Use `npm run dev` for auto-restart on file changes.

Config lives in `.env`:

```
PORT=4000
JWT_SECRET=super-secret-dev-key-change-in-production   # change in production!
CORS_ORIGIN=*                                            # set to your frontend origin
DB_PATH=./data/transitops.db
```

**Demo login** (matches the placeholder values already in the UI's login form):
- email: `ops@transitops.io`
- password: `demo1234`

## Auth

`POST /api/auth/login` returns a JWT. Send it on every subsequent request:

```
Authorization: Bearer <token>
```

All routes under `/api/*` except `/api/auth/login` and `/api/health` require this header.

| Method | Path | Description |
|---|---|---|
| POST | `/api/auth/login` | `{ email, password }` → `{ token, user }` |
| GET | `/api/auth/me` | current user from token |

## Resources

Each resource supports the same REST shape:

```
GET    /api/<resource>          list (supports filters, see below)
GET    /api/<resource>/:id      single record
POST   /api/<resource>          create
PUT    /api/<resource>/:id      partial update
DELETE /api/<resource>/:id      delete → 204
```

| Resource | Path | Filters (`?field=value`) | Search |
|---|---|---|---|
| Vehicles | `/api/vehicles` | `status`, `fuelType`, `type` | `?q=` on plate |
| Drivers | `/api/drivers` | `status` | `?q=` on name |
| Trips | `/api/trips` | `status`, `vehicle`, `driver` | `?q=` on origin |
| Maintenance | `/api/maintenance` | `status`, `vehicle` | `?q=` on type |
| Fuel logs | `/api/fuel-logs` | `vehicle` | `?q=` on station |
| Expenses | `/api/expenses` | `category`, `vehicle` | `?q=` on description |

Field shapes match the TypeScript interfaces in `src/lib/mock.ts` exactly (`Vehicle`, `Driver`, `Trip`, `MaintenanceRecord`, `FuelLog`, `Expense`).

## Dashboard

`GET /api/dashboard` — computed live from the database (not hardcoded), returns:

```json
{
  "kpis": {
    "activeVehicles": 5,
    "totalVehicles": 8,
    "driversOnDuty": 4,
    "totalDrivers": 7,
    "tripsThisWeek": 6,
    "fuelSpendMtd": 25719.2
  },
  "fleetTrend": [{ "month": "Jul", "trips": 6, "distance": 1325 }],
  "fuelSpendTrend": [{ "week": "W1", "diesel": 3868, "electric": 0 }],
  "utilizationByType": [{ "name": "Truck", "value": 2 }]
}
```

This directly replaces `fleetTrend`, `fuelSpendTrend`, `utilizationByType`, and the KPI numbers currently hardcoded in `src/routes/_app.dashboard.tsx`.

## Wiring up the frontend

Drop `frontend-api-client.ts` (included alongside this README) into `src/lib/api.ts` in the UI project. It exposes the same function names as `mock.ts` (`fetchVehicles`, `fetchDrivers`, etc.) plus `login`/`logout`/CRUD helpers, so route files can switch imports from `@/lib/mock` to `@/lib/api` with little else changing. Set `VITE_API_URL` in the UI's `.env` to point at this server (defaults to `http://localhost:4000`).

## Notes / production hardening

- SQLite file lives at `data/transitops.db` (gitignored). For multi-instance deployments, swap in Postgres — the CRUD factory in `src/routes/crud-factory.js` is the only place with SQL to change.
- Change `JWT_SECRET` and restrict `CORS_ORIGIN` before deploying.
- Add rate limiting (e.g. `express-rate-limit`) on `/api/auth/login` before going to production.
