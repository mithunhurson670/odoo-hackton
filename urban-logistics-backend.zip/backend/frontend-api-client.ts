// Real API client for the TransitOps backend.
// Drop this in as src/lib/api.ts and swap `@/lib/mock` imports for `@/lib/api`
// in route files. Exported types + function names intentionally match mock.ts.

export type VehicleStatus = "active" | "maintenance" | "idle" | "retired";
export type DriverStatus = "on-duty" | "off-duty" | "on-leave";
export type TripStatus = "scheduled" | "in-transit" | "completed" | "cancelled";
export type MaintenanceStatus = "scheduled" | "in-progress" | "completed" | "overdue";

export interface Vehicle {
  id: string;
  plate: string;
  model: string;
  type: string;
  year: number;
  odometer: number;
  status: VehicleStatus;
  driver?: string | null;
  fuelType: "Diesel" | "Petrol" | "Electric";
}

export interface Driver {
  id: string;
  name: string;
  phone: string;
  license: string;
  licenseExpiry: string;
  status: DriverStatus;
  rating: number;
  assignedVehicle?: string | null;
}

export interface Trip {
  id: string;
  origin: string;
  destination: string;
  vehicle: string;
  driver: string;
  departure: string;
  arrival: string;
  distanceKm: number;
  status: TripStatus;
}

export interface MaintenanceRecord {
  id: string;
  vehicle: string;
  type: string;
  date: string;
  cost: number;
  status: MaintenanceStatus;
  notes?: string | null;
}

export interface FuelLog {
  id: string;
  vehicle: string;
  date: string;
  liters: number;
  costPerLiter: number;
  total: number;
  odometer: number;
  station: string;
}

export interface Expense {
  id: string;
  category: string;
  description: string;
  date: string;
  amount: number;
  vehicle?: string | null;
}

export interface DashboardData {
  kpis: {
    activeVehicles: number;
    totalVehicles: number;
    driversOnDuty: number;
    totalDrivers: number;
    tripsThisWeek: number;
    fuelSpendMtd: number;
  };
  fleetTrend: { month: string; trips: number; distance: number }[];
  fuelSpendTrend: { week: string; diesel: number; electric: number }[];
  utilizationByType: { name: string; value: number }[];
}

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";
const TOKEN_KEY = "transitops_token";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function logout() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

// ---- Auth ----
export async function login(email: string, password: string) {
  const data = await request<{ token: string; user: { id: string; name: string; email: string; role: string } }>(
    "/api/auth/login",
    { method: "POST", body: JSON.stringify({ email, password }) },
  );
  setToken(data.token);
  return data.user;
}

// ---- Fetchers (same names as mock.ts) ----
export const fetchVehicles = () => request<Vehicle[]>("/api/vehicles");
export const fetchDrivers = () => request<Driver[]>("/api/drivers");
export const fetchTrips = () => request<Trip[]>("/api/trips");
export const fetchMaintenance = () => request<MaintenanceRecord[]>("/api/maintenance");
export const fetchFuelLogs = () => request<FuelLog[]>("/api/fuel-logs");
export const fetchExpenses = () => request<Expense[]>("/api/expenses");
export const fetchDashboard = () => request<DashboardData>("/api/dashboard");

// ---- CRUD helpers ----
export const createVehicle = (data: Omit<Vehicle, "id">) =>
  request<Vehicle>("/api/vehicles", { method: "POST", body: JSON.stringify(data) });
export const updateVehicle = (id: string, data: Partial<Vehicle>) =>
  request<Vehicle>(`/api/vehicles/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteVehicle = (id: string) => request<void>(`/api/vehicles/${id}`, { method: "DELETE" });

export const createDriver = (data: Omit<Driver, "id">) =>
  request<Driver>("/api/drivers", { method: "POST", body: JSON.stringify(data) });
export const updateDriver = (id: string, data: Partial<Driver>) =>
  request<Driver>(`/api/drivers/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteDriver = (id: string) => request<void>(`/api/drivers/${id}`, { method: "DELETE" });

export const createTrip = (data: Omit<Trip, "id">) =>
  request<Trip>("/api/trips", { method: "POST", body: JSON.stringify(data) });
export const updateTrip = (id: string, data: Partial<Trip>) =>
  request<Trip>(`/api/trips/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteTrip = (id: string) => request<void>(`/api/trips/${id}`, { method: "DELETE" });

export const createMaintenance = (data: Omit<MaintenanceRecord, "id">) =>
  request<MaintenanceRecord>("/api/maintenance", { method: "POST", body: JSON.stringify(data) });
export const updateMaintenance = (id: string, data: Partial<MaintenanceRecord>) =>
  request<MaintenanceRecord>(`/api/maintenance/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteMaintenance = (id: string) => request<void>(`/api/maintenance/${id}`, { method: "DELETE" });

export const createFuelLog = (data: Omit<FuelLog, "id">) =>
  request<FuelLog>("/api/fuel-logs", { method: "POST", body: JSON.stringify(data) });
export const updateFuelLog = (id: string, data: Partial<FuelLog>) =>
  request<FuelLog>(`/api/fuel-logs/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteFuelLog = (id: string) => request<void>(`/api/fuel-logs/${id}`, { method: "DELETE" });

export const createExpense = (data: Omit<Expense, "id">) =>
  request<Expense>("/api/expenses", { method: "POST", body: JSON.stringify(data) });
export const updateExpense = (id: string, data: Partial<Expense>) =>
  request<Expense>(`/api/expenses/${id}`, { method: "PUT", body: JSON.stringify(data) });
export const deleteExpense = (id: string) => request<void>(`/api/expenses/${id}`, { method: "DELETE" });
