import "dotenv/config";
import express from "express";
import cors from "cors";
import morgan from "morgan";

import "./db/index.js"; // ensures tables exist on boot
import authRouter from "./routes/auth.js";
import dashboardRouter from "./routes/dashboard.js";
import { vehiclesRouter, driversRouter, tripsRouter, maintenanceRouter, fuelLogsRouter, expensesRouter } from "./routes/resources.js";
import { requireAuth } from "./middleware/auth.js";

const app = express();
const PORT = process.env.PORT || 4000;
const ORIGIN = process.env.CORS_ORIGIN || "*";

app.use(cors({ origin: ORIGIN }));
app.use(express.json());
app.use(morgan("dev"));

app.get("/api/health", (req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

app.use("/api/auth", authRouter);

// Everything below requires a valid Bearer token
app.use("/api", requireAuth);
app.use("/api/dashboard", dashboardRouter);
app.use("/api/vehicles", vehiclesRouter);
app.use("/api/drivers", driversRouter);
app.use("/api/trips", tripsRouter);
app.use("/api/maintenance", maintenanceRouter);
app.use("/api/fuel-logs", fuelLogsRouter);
app.use("/api/expenses", expensesRouter);

app.use((req, res) => res.status(404).json({ error: "Not found" }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`TransitOps API listening on http://localhost:${PORT}`);
});
