import { Router } from "express";
import { nanoid } from "nanoid";
import db from "../db/index.js";

/**
 * Builds a standard REST CRUD router backed by a SQLite table.
 *
 * @param {object} opts
 * @param {string} opts.table - SQL table name
 * @param {string} opts.idPrefix - prefix used when generating new ids, e.g. "V"
 * @param {import("zod").ZodSchema} opts.createSchema - zod schema for POST body
 * @param {import("zod").ZodSchema} opts.updateSchema - zod schema for PATCH/PUT body (all optional)
 * @param {string[]} opts.filterableFields - columns allowed as ?field=value query filters
 * @param {string} [opts.searchField] - a text column to support ?q= substring search on
 */
export function createCrudRouter({ table, idPrefix, createSchema, updateSchema, filterableFields = [], searchField }) {
  const router = Router();

  router.get("/", (req, res) => {
    let sql = `SELECT * FROM ${table}`;
    const clauses = [];
    const params = {};

    for (const field of filterableFields) {
      if (req.query[field] !== undefined) {
        clauses.push(`${field} = @${field}`);
        params[field] = req.query[field];
      }
    }

    if (searchField && req.query.q) {
      clauses.push(`${searchField} LIKE @q`);
      params.q = `%${req.query.q}%`;
    }

    if (clauses.length) sql += ` WHERE ${clauses.join(" AND ")}`;
    sql += ` ORDER BY createdAt DESC`;

    const rows = db.prepare(sql).all(params);
    res.json(rows);
  });

  router.get("/:id", (req, res) => {
    const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(req.params.id);
    if (!row) return res.status(404).json({ error: `${table} record not found` });
    res.json(row);
  });

  router.post("/", (req, res) => {
    const parsed = createSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
    }

    const id = req.body.id || `${idPrefix}-${nanoid(8)}`;
    const data = { id, ...parsed.data };
    const columns = Object.keys(data);
    const sql = `INSERT INTO ${table} (${columns.join(",")}) VALUES (${columns.map((c) => `@${c}`).join(",")})`;

    try {
      db.prepare(sql).run(data);
    } catch (err) {
      return res.status(409).json({ error: "Could not create record", details: err.message });
    }

    const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
    res.status(201).json(row);
  });

  router.put("/:id", (req, res) => {
    const existing = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(req.params.id);
    if (!existing) return res.status(404).json({ error: `${table} record not found` });

    const parsed = updateSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
    }

    const updates = parsed.data;
    const columns = Object.keys(updates);
    if (columns.length === 0) {
      return res.status(400).json({ error: "No fields provided to update" });
    }

    const setClause = columns.map((c) => `${c} = @${c}`).join(", ");
    const sql = `UPDATE ${table} SET ${setClause}, updatedAt = datetime('now') WHERE id = @id`;

    db.prepare(sql).run({ ...updates, id: req.params.id });
    const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(req.params.id);
    res.json(row);
  });

  router.delete("/:id", (req, res) => {
    const result = db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(req.params.id);
    if (result.changes === 0) return res.status(404).json({ error: `${table} record not found` });
    res.status(204).send();
  });

  return router;
}
