import { Router } from "express";
import db from "../db/index.js";

const router = Router();

const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function startOfWeek(date) {
  const d = new Date(date);
  const day = (d.getDay() + 6) % 7; // Monday = 0
  d.setDate(d.getDate() - day);
  d.setHours(0, 0, 0, 0);
  return d;
}

router.get("/", (req, res) => {
  const vehicles = db.prepare(`SELECT * FROM vehicles`).all();
  const drivers = db.prepare(`SELECT * FROM drivers`).all();
  const trips = db.prepare(`SELECT * FROM trips`).all();
  const fuelLogs = db.prepare(`SELECT * FROM fuel_logs`).all();

  // ---- KPIs ----
  const activeVehicles = vehicles.filter((v) => v.status === "active").length;
  const driversOnDuty = drivers.filter((d) => d.status === "on-duty").length;

  const now = new Date();
  const weekStart = startOfWeek(now);
  const tripsThisWeek = trips.filter((t) => new Date(t.departure) >= weekStart).length;

  const monthPrefix = now.toISOString().slice(0, 7); // "YYYY-MM"
  const fuelSpendMtd = fuelLogs
    .filter((f) => f.date.startsWith(monthPrefix))
    .reduce((sum, f) => sum + f.total, 0);

  // ---- fleetTrend: trips + distance grouped by month (last 6 months present in data) ----
  const monthBuckets = new Map();
  for (const t of trips) {
    const key = t.departure.slice(0, 7); // YYYY-MM
    if (!monthBuckets.has(key)) monthBuckets.set(key, { trips: 0, distance: 0 });
    const bucket = monthBuckets.get(key);
    bucket.trips += 1;
    bucket.distance += t.distanceKm;
  }
  const fleetTrend = [...monthBuckets.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, v]) => ({
      month: MONTH_NAMES[Number(key.slice(5, 7)) - 1],
      trips: v.trips,
      distance: Math.round(v.distance),
    }));

  // ---- fuelSpendTrend: diesel vs electric spend grouped by ISO week ----
  const vehicleFuelType = new Map(vehicles.map((v) => [v.plate, v.fuelType]));
  const weekBuckets = new Map();
  const sortedFuelLogs = [...fuelLogs].sort((a, b) => a.date.localeCompare(b.date));
  for (const f of sortedFuelLogs) {
    const weekKey = startOfWeek(f.date).toISOString().slice(0, 10);
    if (!weekBuckets.has(weekKey)) weekBuckets.set(weekKey, { diesel: 0, electric: 0 });
    const bucket = weekBuckets.get(weekKey);
    const fuelType = vehicleFuelType.get(f.vehicle);
    if (fuelType === "Electric") bucket.electric += f.total;
    else bucket.diesel += f.total;
  }
  const fuelSpendTrend = [...weekBuckets.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, v], i) => ({
      week: `W${i + 1}`,
      diesel: Math.round(v.diesel),
      electric: Math.round(v.electric),
    }));

  // ---- utilizationByType: vehicle count by type ----
  const typeBuckets = new Map();
  for (const v of vehicles) {
    typeBuckets.set(v.type, (typeBuckets.get(v.type) || 0) + 1);
  }
  const utilizationByType = [...typeBuckets.entries()].map(([name, value]) => ({ name, value }));

  res.json({
    kpis: {
      activeVehicles,
      totalVehicles: vehicles.length,
      driversOnDuty,
      totalDrivers: drivers.length,
      tripsThisWeek,
      fuelSpendMtd: Math.round(fuelSpendMtd * 100) / 100,
    },
    fleetTrend,
    fuelSpendTrend,
    utilizationByType,
  });
});

export default router;
