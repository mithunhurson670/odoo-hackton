import { z } from "zod";
import { createCrudRouter } from "./crud-factory.js";

// ---- Vehicles ----
const vehicleBase = {
  plate: z.string().min(1),
  model: z.string().min(1),
  type: z.string().min(1),
  year: z.number().int(),
  odometer: z.number().nonnegative(),
  status: z.enum(["active", "maintenance", "idle", "retired"]),
  driver: z.string().nullable().optional(),
  fuelType: z.enum(["Diesel", "Petrol", "Electric"]),
};
export const vehiclesRouter = createCrudRouter({
  table: "vehicles",
  idPrefix: "V",
  createSchema: z.object(vehicleBase),
  updateSchema: z.object(vehicleBase).partial(),
  filterableFields: ["status", "fuelType", "type"],
  searchField: "plate",
});

// ---- Drivers ----
const driverBase = {
  name: z.string().min(1),
  phone: z.string().min(1),
  license: z.string().min(1),
  licenseExpiry: z.string().min(1),
  status: z.enum(["on-duty", "off-duty", "on-leave"]),
  rating: z.number().min(0).max(5),
  assignedVehicle: z.string().nullable().optional(),
};
export const driversRouter = createCrudRouter({
  table: "drivers",
  idPrefix: "D",
  createSchema: z.object(driverBase),
  updateSchema: z.object(driverBase).partial(),
  filterableFields: ["status"],
  searchField: "name",
});

// ---- Trips ----
const tripBase = {
  origin: z.string().min(1),
  destination: z.string().min(1),
  vehicle: z.string().min(1),
  driver: z.string().min(1),
  departure: z.string().min(1),
  arrival: z.string().min(1),
  distanceKm: z.number().nonnegative(),
  status: z.enum(["scheduled", "in-transit", "completed", "cancelled"]),
};
export const tripsRouter = createCrudRouter({
  table: "trips",
  idPrefix: "T",
  createSchema: z.object(tripBase),
  updateSchema: z.object(tripBase).partial(),
  filterableFields: ["status", "vehicle", "driver"],
  searchField: "origin",
});

// ---- Maintenance ----
const maintenanceBase = {
  vehicle: z.string().min(1),
  type: z.string().min(1),
  date: z.string().min(1),
  cost: z.number().nonnegative(),
  status: z.enum(["scheduled", "in-progress", "completed", "overdue"]),
  notes: z.string().nullable().optional(),
};
export const maintenanceRouter = createCrudRouter({
  table: "maintenance",
  idPrefix: "M",
  createSchema: z.object(maintenanceBase),
  updateSchema: z.object(maintenanceBase).partial(),
  filterableFields: ["status", "vehicle"],
  searchField: "type",
});

// ---- Fuel logs ----
const fuelLogBase = {
  vehicle: z.string().min(1),
  date: z.string().min(1),
  liters: z.number().positive(),
  costPerLiter: z.number().positive(),
  total: z.number().nonnegative(),
  odometer: z.number().nonnegative(),
  station: z.string().min(1),
};
export const fuelLogsRouter = createCrudRouter({
  table: "fuel_logs",
  idPrefix: "F",
  createSchema: z.object(fuelLogBase),
  updateSchema: z.object(fuelLogBase).partial(),
  filterableFields: ["vehicle"],
  searchField: "station",
});

// ---- Expenses ----
const expenseBase = {
  category: z.string().min(1),
  description: z.string().min(1),
  date: z.string().min(1),
  amount: z.number().nonnegative(),
  vehicle: z.string().nullable().optional(),
};
export const expensesRouter = createCrudRouter({
  table: "expenses",
  idPrefix: "E",
  createSchema: z.object(expenseBase),
  updateSchema: z.object(expenseBase).partial(),
  filterableFields: ["category", "vehicle"],
  searchField: "description",
});
